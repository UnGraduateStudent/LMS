
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */

import java.sql.*;
import javax.swing.*;

public class DBConnection
{
    public static Connection getConnection()
    {
    Connection conn=null;
    try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/library?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "library", "library");
         }
    catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
    return conn;
    }

}   

